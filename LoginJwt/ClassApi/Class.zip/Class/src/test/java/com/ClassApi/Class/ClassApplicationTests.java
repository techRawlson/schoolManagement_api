package com.ClassApi.Class;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassApplicationTests {

	@Test
	void contextLoads() {
	}

}
